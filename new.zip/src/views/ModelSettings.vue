<template>
  <div class="page-container">
    <h2>模型设置</h2>
    <el-form label-width="120px">
      <el-form-item label="模型版本">
        <el-select placeholder="请选择版本">
          <el-option label="诸葛天机 V26.5" value="26.5" />
        </el-select>
      </el-form-item>
    </el-form>
  </div>
</template>