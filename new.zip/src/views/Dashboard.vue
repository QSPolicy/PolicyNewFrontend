<template>
  <component is="style">
    @import url('https://app.windfonts.com/api/css?family=wenfeng-ysbth:wght@bold');
  </component>

  <div class="page-container">
    <div class="header-section">
      <h2 class="sub-title wf-font-ysbth-bold">全球科技布局，战略规划，资助动向，政策信息，</h2>
      <h1 class="main-title wf-font-ysbth-bold">一键直达</h1>
    </div>

    <div class="search-wrapper">
      <div class="gradient-border-box">
        <div class="search-content">
          <input 
            type="text" 
            placeholder="输入关键词，支持段落级语义检索，描述越详细，检索越精准" 
            class="custom-input"
          />
          
          <div class="action-group">
            <el-icon class="send-icon"><Promotion /></el-icon>
            
            <div class="switch-container">
              <el-switch
                v-model="isGlobalSearch"
                active-color="#00e676"
                inactive-color="#dcdfe6"
              />
              <span class="switch-label">全网检索</span>
            </div>
          </div>
        </div>
      </div>
      <el-icon class="settings-icon"><Operation /></el-icon>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { Promotion, Operation } from '@element-plus/icons-vue'

const isGlobalSearch = ref(true)
</script>

<style scoped>
/* 严格按照你的样式要求进行定义 */
/* font-weight: 字体权重值 决定字体粗细，存在多个变体时，使用变体值  
注：若没有生效可使用 100 - 900 之间的值，若还是没生效说明该变体中没有匹配的样式 
font-style: 字体样式  normal | italic | oblique 控制字体风格，可展示倾斜样式 
*/

.wf-font-ysbth-bold {
    /* 这里的名字必须与文风字体接口返回的名字一致 */
    font-family: 'wenfeng-ysbth';
    font-style: normal;
    font-weight:200 !important;
}
/* 页面整体布局 */
.page-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 40px;
  background-color: transparent;
}

/* 标题样式 */
.header-section {
  text-align: center;
  margin-bottom: 40px;
}

.sub-title {
  font-size: 24px;
  color: #2c3e50;
  letter-spacing: 2px;
  margin-bottom: 15px;
}

.main-title {
  font-size: 56px;
  color: #1a237e; /* 深蓝色 */
  letter-spacing: 4px;
  margin: 0;
}

/* 搜索框相关样式 */
.search-wrapper {
  display: flex;
  align-items: center;
  width: 100%;
  max-width: 900px;
  gap: 15px;
}

.gradient-border-box {
  flex: 1;
  padding: 2px;
  border-radius: 12px;
  background: linear-gradient(to right, #90caf9, #f48fb1, #ffab91);
  position: relative;
}

.search-content {
  background: #fff;
  border-radius: 10px;
  display: flex;
  align-items: center;
  padding: 10px 20px;
}

.custom-input {
  flex: 1;
  border: none;
  outline: none;
  font-size: 16px;
  color: #606266;
  padding: 8px 0;
}

.custom-input::placeholder {
  color: #909399;
  font-size: 14px;
}

.action-group {
  display: flex;
  align-items: center;
  gap: 15px;
  border-left: 1px solid #f0f0f0;
  padding-left: 15px;
}

.send-icon {
  font-size: 24px;
  color: #3f51b5;
  cursor: pointer;
  transform: rotate(-15deg);
}

.switch-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
}

.switch-label {
  font-size: 12px;
  color: #333;
  font-weight: bold;
}

.settings-icon {
  font-size: 28px;
  color: #333;
  cursor: pointer;
}

:deep(.el-switch.is-checked .el-switch__core) {
  background-color: #00e676 !important;
}
</style>