<template>
  <div class="common-layout">
    <el-container style="height: 100vh;">
      <el-aside width="240px" class="aside-container2"></el-aside>
      
      <el-aside width="240px" class="aside-container">
        <div class="logo">
          <img src="./assets/vue.svg" class="logo-icon" />
          <span>诸葛天机V114.5</span>
        </div>

        <div class="menu-wrapper">
          <el-menu
            default-active="/dashboard"
            router
            class="custom-menu"
            :unique-opened="true"
          >
            <el-menu-item index="/dashboard" class="menu-item-card">
              <el-icon><HomeFilled /></el-icon>
              <span>管理中心</span>
              <el-icon class="arrow-right"><ArrowRight /></el-icon>
            </el-menu-item>

            <el-sub-menu index="data">
              <template #title>
                <el-icon><Lightning /></el-icon>
                <span>数据中心</span>
              </template>
              <el-menu-item index="/info-manage">情报管理</el-menu-item>
              <el-menu-item index="1-2">机构管理</el-menu-item>
            </el-sub-menu>

            <el-sub-menu index="settings">
              <template #title>
                <el-icon><Operation /></el-icon>
                <span>设置中心</span>
              </template>
              <el-menu-item index="/model-settings">模型设置</el-menu-item>
              <el-menu-item index="2-2">用户设置</el-menu-item>
              <el-menu-item index="2-3">安全设置</el-menu-item>
            </el-sub-menu>
          </el-menu>
        </div>

        <div class="user-profile">
          <div class="user-card">
            <el-avatar 
              :size="36" 
              src="https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png" 
              class="user-avatar"
            />
            <span class="user-name">管理员114514</span>
          </div>
        </div>
      </el-aside>

      <el-main class="main-content">
        <router-view />
      </el-main>
    </el-container>
  </div>
</template>

<script setup>
import { HomeFilled, Lightning, Operation, ArrowRight } from '@element-plus/icons-vue'
</script>

<style scoped>
/* 容器基础样式 */
.aside-container {
  background-color: #fff;
  border-right: 1px solid #f0f0f0;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  position: fixed;
  height: 100%;
}

.aside-container2 {
  background-color: #fff;
  border-right: 1px solid #f0f0f0;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  position: relative;
  height: 100%;
}

/* 菜单包裹层：自动撑开 */
.menu-wrapper {
  flex: 1;
  overflow-x:hidden;
  overflow-y: auto;
}

/* 底部用户信息容器 */
.user-profile {
  padding: 16px 12px;
  border-top: 1px solid #f0f0f0;
}

.user-card {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 8px 12px;
  cursor: pointer;
  transition: all 0.3s ease;
  border-radius: 50px; /* 初始为大圆角（类似胶囊形或配合内部圆头像） */
}

/* Hover 状态：变为普通圆角 */
.user-card:hover {
  background-color: #f5f7fa;
  border-radius: 8px; /* 修改这里的值来控制 hover 后的圆角弧度 */
}

.user-avatar {
  flex-shrink: 0;
  border: 1px solid #eee;
}

.user-name {
  font-size: 14px;
  color: #303133;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  font-weight: 500;
}

/* --- 原有样式保持不变 --- */
.logo {
  padding: 24px 20px;
  font-size: 20px;
  font-weight: bold;
  display: flex;
  align-items: center;
  gap: 10px;
  color: #303133;
}

.logo-icon {
  width: 32px;
  background: linear-gradient(135deg, #a18cd1 0%, #fbc2eb 100%);
  border-radius: 8px;
  padding: 4px;
}

:deep(.el-menu-item),
:deep(.el-sub-menu__title) {
  height: 50px !important;
  line-height: 50px !important;
  margin: 4px 12px !important; 
  width: calc(100% - 24px) !important; 
  border-radius: 8px !important;
  display: flex !important;
  align-items: center !important;
  transition: all 0.3s ease;
  padding: 0 16px !important; 
}

:deep(.el-menu-item span),
:deep(.el-sub-menu__title span) {
  flex: 1;
}

:deep(.el-sub-menu__icon-arrow) {
  position: static !important;
  margin: 0 !important;
  font-size: 14px !important;
  color: inherit !important;
}

.arrow-right {
  margin-right: 2px !important;
  font-size: 14px !important;
}

:deep(.el-icon) {
  font-size: 20px;
  margin-right: 10px;
  flex-shrink: 0;
}

:deep(.el-menu-item:hover),
:deep(.el-sub-menu__title:hover) {
  background-color: #f5f7fa !important;
  color: #409eff !important;
}

:deep(.el-menu-item.is-active) {
  background-color: #e6f4ff !important;
  color: #1890ff !important;
  font-weight: bold;
}

.custom-menu {
  border-right: none;
}
.main-content {
  background-color: #f5f7fa;
}
</style>